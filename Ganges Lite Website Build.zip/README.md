
  # Ganges Lite Website Build

  This is a code bundle for Ganges Lite Website Build. The original project is available at https://www.figma.com/design/gcwxZed2wjU0fwVrDErOEk/Ganges-Lite-Website-Build.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
# 🚀 GO LIVE NOW - GANGES LITE DEPLOYMENT GUIDE

**Your platform is 100% ready. Follow these steps to go live on lite.ganges.world and start accepting orders TODAY.**

---

## ⚡ QUICK CHECKLIST

Before starting, ensure you have:
- [ ] Supabase account (free tier is fine)
- [ ] Vercel account (free tier is fine)
- [ ] Domain access to ganges.world
- [ ] 30 minutes of time

---

## 📋 STEP 1: DATABASE SETUP (10 minutes)

### 1.1 Create Supabase Project

1. Go to https://supabase.com
2. Click "New Project"
3. Name: `ganges-lite-production`
4. Password: Choose a strong password (save it!)
5. Region: Choose closest to India (Singapore or Mumbai)
6. Click "Create new project"
7. Wait 2-3 minutes for project to be ready

### 1.2 Run Initial Database Migration

1. In Supabase dashboard, click **"SQL Editor"** (left sidebar)
2. Click **"New query"**
3. Open file: `/supabase/migrations/001_initial_schema.sql` from your project
4. Copy ALL 450+ lines
5. Paste into SQL Editor
6. Click **"RUN"** button
7. Wait for "Success" message (should take 5-10 seconds)

**Expected result:** 
```
Success. No rows returned
Time: 1.5s
```

### 1.3 Run Feature Migration

1. Click **"New query"** again
2. Open file: `/supabase/migrations/002_add_new_features.sql`
3. Copy ALL lines
4. Paste into SQL Editor
5. Click **"RUN"**
6. Wait for "Success" message

**Expected result:**
```
Success. No rows returned
Time: 0.8s
```

### 1.4 Get Supabase Credentials

1. Click **"Settings"** (gear icon in left sidebar)
2. Click **"API"**
3. Copy these values (you'll need them):
   - **Project URL** (looks like: https://xxxxx.supabase.co)
   - **anon public** key (long string starting with ey...)
   - **service_role** key (longer string, starts with ey...)

4. Also get **Project Reference ID**:
   - It's in the URL: https://supabase.com/dashboard/project/**xxxxx**
   - Or in Settings > General > Reference ID

**✅ Database setup complete!**

---

## 📋 STEP 2: CONFIGURE YOUR PROJECT (5 minutes)

### 2.1 Update Supabase Info File

1. Open `/utils/supabase/info.tsx` in your project
2. You'll see:
```tsx
export const projectId = 'your-project-id';
export const publicAnonKey = 'your-anon-key';
```

3. Replace with YOUR values from Step 1.4:
```tsx
export const projectId = 'xxxxx'; // Your Project Reference ID
export const publicAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'; // Your anon key
```

4. Save the file

### 2.2 Set Up Environment Variables

Create a file `.env.local` in root folder:

```env
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

Replace with your actual values.

**✅ Project configured!**

---

## 📋 STEP 3: TEST LOCALLY (5 minutes)

### 3.1 Install and Run

```bash
# Install dependencies (if not done already)
npm install

# Start development server
npm run dev
```

### 3.2 Test Key Features

Open http://localhost:5173 and test:

**Sign Up Flow:**
1. Click "Sign Up"
2. Fill form with test data
3. Add referral code if you want (optional)
4. Click "Create Account"
5. Should show success message
6. Try signing in

**Dashboard:**
1. Sign in with test account
2. Check dashboard loads
3. Verify locker number shows (e.g., GL-1001)
4. Click through all 18 sections
5. Test copy buttons (address, coupons, referral)

**If everything works, proceed to deployment!**

---

## 📋 STEP 4: DEPLOY TO VERCEL (5 minutes)

### 4.1 Install Vercel CLI

```bash
npm install -g vercel
```

### 4.2 Login to Vercel

```bash
vercel login
```

Follow prompts to log in (GitHub, GitLab, Bitbucket, or Email)

### 4.3 Deploy

```bash
# Deploy to production
vercel --prod
```

**Answer prompts:**
- Set up and deploy? **Y**
- Which scope? Choose your account
- Link to existing project? **N**
- Project name? **ganges-lite**
- In which directory? **./` (just press Enter)
- Override settings? **N**

**Wait 2-3 minutes for deployment...**

### 4.4 Add Environment Variables to Vercel

1. Go to https://vercel.com/dashboard
2. Click your **ganges-lite** project
3. Click **Settings**
4. Click **Environment Variables**
5. Add these three variables:

**Variable 1:**
- Name: `VITE_SUPABASE_URL`
- Value: `https://xxxxx.supabase.co` (your project URL)
- Environment: Production, Preview, Development (check all)
- Click **Save**

**Variable 2:**
- Name: `VITE_SUPABASE_ANON_KEY`
- Value: Your anon key (starts with eyJ...)
- Environment: Production, Preview, Development
- Click **Save**

### 4.5 Redeploy with Environment Variables

```bash
vercel --prod
```

**Vercel will give you a URL like:**
`https://ganges-lite-xxxxx.vercel.app`

Test this URL - your app should work!

**✅ Deployed to Vercel!**

---

## 📋 STEP 5: CONFIGURE CUSTOM DOMAIN (3 minutes)

### 5.1 Add Domain in Vercel

1. In Vercel dashboard → Your project → **Settings** → **Domains**
2. Click **"Add"**
3. Enter: `lite.ganges.world`
4. Click **"Add"**

**Vercel will show you DNS settings needed:**

### 5.2 Update DNS Records

Go to your domain provider (where ganges.world is registered):

1. Add **CNAME record**:
   - **Type:** CNAME
   - **Name:** lite
   - **Value:** cname.vercel-dns.com
   - **TTL:** 3600 (or Auto)

2. Click **Save**

### 5.3 Wait for DNS Propagation

- Usually takes 5-30 minutes
- Can take up to 48 hours in rare cases
- Check status in Vercel dashboard

**When it shows "Valid Configuration" ✅, you're live!**

Visit: https://lite.ganges.world

**✅ Custom domain configured!**

---

## 📋 STEP 6: CONFIGURE GOOGLE SIGN-IN (5 minutes) - OPTIONAL

### 6.1 Enable in Supabase

1. Supabase Dashboard → **Authentication** → **Providers**
2. Find **Google**
3. Toggle **"Enable Sign in with Google"**

### 6.2 Create Google OAuth Credentials

1. Go to https://console.cloud.google.com
2. Create new project or select existing
3. Go to **APIs & Services** → **Credentials**
4. Click **"Create Credentials"** → **"OAuth 2.0 Client ID"**
5. Application type: **Web application**
6. Name: **Ganges Lite Production**
7. **Authorized redirect URIs:** Add this:
   ```
   https://xxxxx.supabase.co/auth/v1/callback
   ```
   (Replace xxxxx with YOUR Supabase project ID)
8. Click **"Create"**
9. Copy **Client ID** and **Client Secret**

### 6.3 Add to Supabase

1. Back in Supabase → Authentication → Providers → Google
2. Paste **Client ID**
3. Paste **Client Secret**
4. Click **"Save"**

### 6.4 Test Google Sign-In

1. Go to https://lite.ganges.world
2. Click **"Sign Up"** or **"Sign In"**
3. Click **"Sign in with Google"**
4. Choose Google account
5. Should create account and redirect back
6. Check dashboard loads with locker number

**✅ Google Sign-In working!**

---

## 📋 STEP 7: CREATE ADMIN ACCOUNT (2 minutes)

### 7.1 Sign Up as Admin

1. Go to https://lite.ganges.world
2. Click **"Sign Up"**
3. Use email: **gangescompany@gmail.com**
4. Create password (SAVE THIS!)
5. Fill other details
6. Click **"Create Account"**

### 7.2 Access Admin Panel

1. Go to: https://lite.ganges.world
2. Click **"Admin"** in navbar (top right)
3. Sign in with gangescompany@gmail.com
4. You should see admin dashboard

### 7.3 Test Admin Functions

Check these tabs:
- **Dashboard** - Shows stats
- **Users** - Shows all registered users
- **Packages** - Can update statuses
- **Transactions** - Can approve payments
- **Personal Shopper** - Can manage requests

**✅ Admin panel ready!**

---

## 🎉 YOU'RE LIVE! NOW START MARKETING

Your platform is now fully operational at https://lite.ganges.world

---

## 📱 ACCEPT YOUR FIRST ORDER

### Customer Journey:

1. **Customer signs up** → Gets locker number (GL-1001, GL-1002, etc.)
2. **Customer shops** → Uses virtual address with their locker number
3. **Package arrives** → You update in admin panel
4. **Customer requests ship** → Creates ship request from locker section
5. **Customer pays** → Via WhatsApp, you verify in admin
6. **You ship** → Update tracking in admin panel
7. **Customer receives** → Happy customer! 🎉

### WhatsApp Payment Flow:

1. Customer clicks "Add Funds via WhatsApp" in wallet
2. WhatsApp opens with pre-filled message
3. Customer tells you amount to add
4. You provide payment details (UPI/Bank Transfer)
5. Customer sends screenshot
6. You approve in **Admin → Transactions** tab
7. Wallet credited automatically

---

## 🔧 DAILY OPERATIONS

### Check These Daily:

1. **New Signups**
   - Admin → Users tab
   - See new customers

2. **Package Updates**
   - Admin → Packages tab
   - Update statuses when packages arrive/ship

3. **Payment Approvals**
   - Admin → Transactions tab
   - Approve WhatsApp payments

4. **Personal Shopper Requests**
   - Admin → Personal Shopper tab
   - Quote and process requests

5. **WhatsApp Messages**
   - Respond to customer queries
   - Process payment requests

---

## 🐛 TROUBLESHOOTING

### "Database error" when signing up

**Problem:** Migration didn't run or failed

**Fix:**
1. Go to Supabase → SQL Editor
2. Run: `SELECT * FROM user_profiles;`
3. If error, re-run both migration files
4. Make sure all tables exist

### Locker number not showing

**Problem:** Trigger not created

**Fix:**
1. Go to Supabase → Database → Functions
2. Should see `assign_locker_number` function
3. If missing, re-run migration 002

### Copy buttons not working

**Problem:** Browser clipboard permissions

**Fix:**
1. Make sure site is HTTPS (Vercel provides this)
2. In Chrome: Settings → Privacy → Site Settings → Clipboard → Allow
3. Try in different browser

### Google Sign-In not working

**Problem:** OAuth not configured or wrong redirect URI

**Fix:**
1. Check Supabase → Authentication → Providers → Google
2. Verify Client ID and Secret are correct
3. Check redirect URI matches: `https://YOUR-PROJECT.supabase.co/auth/v1/callback`
4. Wait 5 minutes after saving for changes to propagate

### Admin panel not loading

**Problem:** Not logged in as admin email

**Fix:**
1. Make sure you're logged in with `gangescompany@gmail.com`
2. If using different email, add it to adminEmails array in `/services/api.service.ts`:
```tsx
const adminEmails = ['gangescompany@gmail.com', 'your-email@example.com'];
```
3. Redeploy

### Custom domain not working

**Problem:** DNS not propagated yet

**Fix:**
1. Wait up to 48 hours (usually much faster)
2. Check DNS propagation: https://dnschecker.org
3. Enter: lite.ganges.world
4. Should show CNAME pointing to vercel
5. If still issues, check domain provider DNS settings

---

## 📊 MONITORING YOUR BUSINESS

### Track These Metrics:

1. **User Signups**
   - Go to Admin → Users
   - See total users
   - Growth rate

2. **Packages in Locker**
   - Admin → Packages
   - Filter by "Warehouse" status
   - Storage charges to collect

3. **Revenue**
   - Admin → Transactions
   - Total approved payments
   - Wallet credits

4. **Personal Shopper Requests**
   - Admin → Personal Shopper
   - Pending requests
   - Completed orders

---

## 🎯 FIRST WEEK GOALS

### Day 1-2:
- [ ] Get 5-10 test signups (friends/family)
- [ ] Test full customer journey
- [ ] Fix any issues found
- [ ] Perfect your WhatsApp responses

### Day 3-4:
- [ ] Post on social media (Instagram @ganges_world)
- [ ] Share referral link
- [ ] Target NRI communities
- [ ] Offer launch discount

### Day 5-7:
- [ ] Get first 10 real customers
- [ ] Process first 5 packages
- [ ] Get first reviews
- [ ] Refine processes

---

## 💰 PRICING REMINDER

### Shipping Rates:
- **Economy:** ₹2500/kg (15-20 days)
- **Ganges One:** ₹3500/kg (7-15 days)

### Additional Services:
- **Personal Shopper:** 7% of product value
- **Discard shoe boxes:** ₹90
- **Extra packaging:** ₹90
- **Gift wrap:** ₹90
- **Gift note:** ₹90

### Locker Storage:
- **Free:** First 20 days
- **After 20 days:** ₹100/day (auto-deducted from wallet)

### Referral Bonus:
- **Referrer:** ₹200 credit
- **Referee:** ₹200 credit

---

## 📞 CUSTOMER SUPPORT

### WhatsApp: +91 82098 93843

**Response Templates:**

**Welcome Message:**
```
Hi! Welcome to Ganges Lite 🎉

Your locker is GL-XXXX

Use this address for shopping:
[Customer Name]
Locker: GL-XXXX
Ganges, Horizon Tower
Malviya Nagar, Jaipur - 302017
Rajasthan, India

Need help? Just ask!
```

**Payment Details:**
```
Hi! To add ₹[AMOUNT] to your wallet:

UPI ID: ganges@paytm
OR
Bank Transfer:
Name: Ganges Lite
Bank: [Your Bank]
Account: [Your Account]
IFSC: [Your IFSC]

Please send screenshot after payment!
```

**Package Arrival:**
```
Great news! 📦

Your package has arrived at our warehouse!

Login to dashboard and create a ship request.
We'll deliver it to you soon!
```

---

## 🎨 BRANDING

### Colors:
- Primary: Orange (#f97316)
- Secondary: Pink (#ec4899)
- Sidebar: Blue gradient (#1e3a8a to #172554)

### Social Media:
- Instagram: @ganges_world
- Email: gangescompany@gmail.com
- Website: https://lite.ganges.world

### Logo:
- Available in `/imports` folder
- Use consistently everywhere

---

## 📈 SCALE YOUR BUSINESS

### When You Have 50+ Customers:

1. **Hire Help**
   - Package handler
   - Customer support
   - Admin assistant

2. **Automate More**
   - Email notifications
   - SMS updates
   - Auto-payment gateway (Stripe/Razorpay)

3. **Expand Services**
   - More courier options
   - Package consolidation
   - Express shipping

4. **Marketing**
   - Google Ads
   - Facebook Ads
   - Influencer partnerships
   - YouTube tutorials

---

## ✅ FINAL CHECKLIST

Before announcing publicly:

### Technical:
- [ ] Site loads at https://lite.ganges.world
- [ ] Can sign up and login
- [ ] Dashboard shows locker number
- [ ] Copy buttons work
- [ ] Admin panel accessible
- [ ] Google Sign-In works (optional)

### Business:
- [ ] WhatsApp number active
- [ ] Payment details ready
- [ ] Warehouse address confirmed
- [ ] Courier partners lined up
- [ ] Pricing finalized

### Marketing:
- [ ] Instagram post ready
- [ ] Launch offer decided
- [ ] Referral program active
- [ ] Target audience identified

---

## 🚀 YOU'RE READY TO LAUNCH!

### Final Steps:

1. **Announce on Instagram:**
```
🚀 Launching Ganges Lite!

Shop from India 🇮🇳, Ship anywhere in the world 🌍

✨ Get your Indian virtual address
📦 Free storage for 20 days
💸 Lowest shipping rates
🎁 ₹200 referral bonus

Sign up now: lite.ganges.world

#GangesLite #IndianShopping #ShipWorldwide
```

2. **WhatsApp Status:**
```
🎉 Big News!

We're launching Ganges Lite - your gateway to shopping from India!

Visit: lite.ganges.world
Sign up and get ₹200 bonus!

Share with friends abroad! 🌍
```

3. **Start Accepting Orders!**

---

## 💡 PRO TIPS

1. **First 24 Hours:** Be extra responsive on WhatsApp
2. **First Week:** Offer 20% off to first 10 customers
3. **Build Trust:** Share tracking updates proactively
4. **Collect Reviews:** Ask happy customers for testimonials
5. **Document Everything:** Take photos of packages for transparency
6. **Be Patient:** Growth takes time, but service quality matters

---

## 🎊 CONGRATULATIONS!

You now have a **fully functional, production-ready** international shipping platform!

**You can:**
- ✅ Accept customer signups
- ✅ Assign unique locker numbers
- ✅ Receive packages at your warehouse
- ✅ Manage payments via WhatsApp
- ✅ Ship internationally
- ✅ Offer personal shopper service
- ✅ Run referral program
- ✅ Track everything in admin panel

**Your platform is ready to make money! 🚀💰**

---

## 📞 NEED HELP?

**Common Issues:** Check Troubleshooting section above

**Technical Issues:**
- Check Supabase logs
- Check Vercel deployment logs
- Check browser console

**Business Questions:**
- Review this guide
- Check admin panel
- Test features yourself first

---

## 📝 REMEMBER

**Success = Consistency + Quality + Customer Service**

- Respond to WhatsApp messages quickly
- Update package statuses daily
- Be transparent with customers
- Under-promise, over-deliver
- Build relationships, not just transactions

---

**You've got everything you need. Now go make it happen! 💪**

**Welcome to the world of international shipping! 🌍✈️📦**

---

*Last Updated: October 11, 2025*
*Version: Production 1.0*
*Status: Ready for Launch 🚀*

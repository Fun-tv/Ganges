# 🔧 TROUBLESHOOTING GUIDE

**Quick fixes for common issues**

---

## 🚨 CRITICAL ERRORS

### ❌ "relation user_profiles does not exist"

**Problem:** Database migration not run

**Fix:**
```sql
-- Run in Supabase SQL Editor
-- File: /supabase/migrations/001_initial_schema.sql
-- Copy ALL lines and run
```

**Verify:**
```sql
SELECT * FROM user_profiles;
-- Should return empty result, not error
```

---

### ❌ "Locker number is null"

**Problem:** Trigger not created or user created before migration

**Fix:**
```sql
-- Run in Supabase SQL Editor
-- File: /supabase/migrations/002_add_new_features.sql
-- Copy ALL lines and run

-- Then assign locker to existing users:
UPDATE user_profiles 
SET locker_number = 'GL-' || (1000 + ROW_NUMBER() OVER (ORDER BY created_at))
WHERE locker_number IS NULL;
```

---

### ❌ "Failed to fetch" or "Network error"

**Problem:** Wrong Supabase credentials

**Fix:**
1. Check `/utils/supabase/info.tsx`
2. Verify `projectId` matches your Supabase project
3. Verify `publicAnonKey` is correct
4. If deployed, check Vercel environment variables

**Get correct values:**
- Supabase Dashboard → Settings → API
- Copy Project URL (extract ID from it)
- Copy anon/public key

---

## 🔐 AUTHENTICATION ISSUES

### ❌ Can't sign up

**Check these:**
1. Migration run? → Check user_profiles table exists
2. Email format valid? → Must be valid email
3. Password long enough? → Minimum 6 characters
4. Check browser console for errors

**Fix:**
```sql
-- Verify table exists
SELECT * FROM user_profiles LIMIT 1;

-- Check for errors
SELECT * FROM auth.users;
```

---

### ❌ Can't sign in

**Check:**
1. Email correct?
2. Password correct?
3. Account created? → Check admin panel
4. Email verified? → We auto-verify, check migration

**Fix:**
```sql
-- Check if user exists
SELECT email FROM auth.users WHERE email = 'test@example.com';

-- Check profile
SELECT * FROM user_profiles WHERE email = 'test@example.com';
```

---

### ❌ Google Sign-In not working

**Check:**
1. Enabled in Supabase? → Auth → Providers → Google
2. Client ID added?
3. Client Secret added?
4. Redirect URI correct? → Must be `https://YOUR-PROJECT.supabase.co/auth/v1/callback`

**Fix:**
1. Go to Google Cloud Console
2. Verify Authorized redirect URIs
3. Must exactly match Supabase URI
4. Wait 5 minutes after changes
5. Try in incognito mode

---

## 💻 DASHBOARD ISSUES

### ❌ Dashboard not loading

**Check:**
1. Signed in? → Check auth state
2. User profile exists? → Check database
3. Console errors? → Press F12

**Fix:**
```tsx
// Check in browser console
localStorage.getItem('user')
// Should show user data

// Check auth state
const { data } = await supabase.auth.getUser();
console.log(data);
```

---

### ❌ Sidebar not visible

**Problem:** CSS issue or wrong component

**Fix:**
1. Hard refresh: Ctrl+F5 or Cmd+Shift+R
2. Clear browser cache
3. Try incognito mode
4. Check if `Dashboard.tsx` was updated
5. Verify bluish background shows

---

### ❌ Copy buttons not working

**Problem:** Clipboard API permissions

**Fix:**
1. Must be HTTPS (HTTP blocks clipboard)
2. Try different browser
3. Check browser settings:
   - Chrome: Settings → Privacy → Clipboard
   - Must allow clipboard access
4. Check console for errors

**Code check:**
```tsx
// Should see this in Dashboard.tsx
navigator.clipboard.writeText(text).then(() => {
  toast.success('Copied!');
}).catch(() => {
  toast.error('Failed to copy');
});
```

---

### ❌ Sections not loading

**Check:**
1. Console errors? → Press F12
2. Data fetching? → Check network tab
3. Supabase connection? → Check credentials

**Fix:**
```tsx
// Add logging in Dashboard.tsx
useEffect(() => {
  console.log('Fetching data...');
  fetchUserData();
}, []);
```

---

## 📦 PACKAGE/DATA ISSUES

### ❌ No packages showing

**This is normal if:**
- No packages added yet
- User hasn't ordered anything

**To test:**
```sql
-- Add test package in Supabase SQL Editor
INSERT INTO packages (
  user_id,
  tracking_number,
  description,
  weight_kg,
  status
) VALUES (
  (SELECT id FROM user_profiles LIMIT 1),
  'TEST123',
  'Test Package',
  2.5,
  'Warehouse'
);
```

---

### ❌ Wallet balance not showing

**Check:**
```sql
-- Verify wallet balance exists
SELECT wallet_balance FROM user_profiles WHERE id = 'USER-ID';

-- If NULL, set default
UPDATE user_profiles 
SET wallet_balance = 0 
WHERE wallet_balance IS NULL;
```

---

### ❌ Referral code not showing

**Check:**
```sql
-- Verify referral code generated
SELECT referral_code FROM user_profiles WHERE id = 'USER-ID';

-- If NULL, generate one
UPDATE user_profiles 
SET referral_code = 'GNG' || UPPER(SUBSTRING(MD5(RANDOM()::TEXT), 1, 6))
WHERE referral_code IS NULL;
```

---

## 🎨 UI/UX ISSUES

### ❌ Sidebar wrong color (black instead of blue)

**Problem:** Old Dashboard.tsx file

**Fix:**
Sidebar should have:
```tsx
className="bg-gradient-to-b from-blue-900 to-blue-950"
```

Active state should have:
```tsx
className="bg-gradient-to-r from-orange-500 to-pink-600"
```

**If wrong:**
1. Check latest Dashboard.tsx was deployed
2. Hard refresh browser
3. Clear cache

---

### ❌ Mobile menu not working

**Check:**
1. Hamburger button visible on mobile?
2. Click triggers sidebar?
3. Overlay shows?

**Debug:**
```tsx
// Check state in Dashboard.tsx
console.log('Sidebar open:', sidebarOpen);
```

---

### ❌ Responsive design broken

**Check:**
1. Tailwind CSS loading?
2. Check `styles/globals.css`
3. Try different screen size
4. Check browser console for CSS errors

**Fix:**
1. Refresh page
2. Clear cache
3. Try incognito
4. Check Tailwind CDN if using

---

## 🔧 ADMIN PANEL ISSUES

### ❌ Can't access admin panel

**Check:**
1. Using admin email? → Must be gangescompany@gmail.com
2. Account created with this email?
3. Signed in?

**Fix:**
```sql
-- Check if admin account exists
SELECT email FROM auth.users WHERE email = 'gangescompany@gmail.com';

-- If not, create one through signup
-- Then verify in admin panel
```

---

### ❌ Admin panel empty

**This is normal if:**
- No users signed up yet
- No packages added yet
- No transactions yet

**To test, add sample data:**
```sql
-- In Supabase SQL Editor
SELECT * FROM user_profiles;
-- Should show all users
```

---

### ❌ Can't update package status

**Check:**
1. Admin logged in?
2. Package exists?
3. Check console for errors

**Debug:**
```sql
-- Verify package exists
SELECT * FROM packages WHERE id = 'PACKAGE-ID';

-- Manually update to test
UPDATE packages SET status = 'In Transit' WHERE id = 'PACKAGE-ID';
```

---

## 🌐 DEPLOYMENT ISSUES

### ❌ Vercel deployment failed

**Check build logs:**
1. Vercel Dashboard → Your Project → Deployments
2. Click failed deployment
3. Read error logs

**Common fixes:**
1. Missing dependencies → `npm install`
2. TypeScript errors → Fix type issues
3. Environment variables → Add in Vercel settings

---

### ❌ Site shows "404 Not Found"

**Problem:** Deployment or routing issue

**Fix:**
1. Check Vercel project status
2. Verify deployment succeeded
3. Check custom domain configuration
4. Wait for DNS propagation

---

### ❌ Environment variables not working

**Problem:** Not set in Vercel

**Fix:**
1. Vercel Dashboard → Settings → Environment Variables
2. Add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
3. Select: Production, Preview, Development
4. Redeploy: `vercel --prod`

---

### ❌ Custom domain not working

**Check:**
1. DNS records correct?
   - Type: CNAME
   - Name: lite
   - Value: cname.vercel-dns.com
2. DNS propagated? → Check dnschecker.org
3. SSL certificate issued? → Usually takes 5-30 minutes

**Fix:**
1. Wait up to 48 hours for DNS
2. Check domain provider DNS settings
3. Remove and re-add domain in Vercel
4. Contact Vercel support if persistent

---

## 📱 WHATSAPP ISSUES

### ❌ WhatsApp button not opening

**Check:**
1. Phone number correct? → +91 82098 93843
2. Message pre-filled?
3. WhatsApp installed? (mobile)

**Fix:**
```tsx
// Check URL format in code
const message = encodeURIComponent('Your message');
const url = `https://wa.me/918209893843?text=${message}`;
```

---

### ❌ Message not pre-filling

**Check:**
1. Special characters encoded?
2. Message not too long?
3. URL format correct?

**Fix:**
Use `encodeURIComponent()` for all message text

---

## 🐛 GENERAL DEBUGGING

### Step 1: Check Console
```
1. Press F12
2. Click Console tab
3. Look for red errors
4. Read error message
5. Google error if unclear
```

### Step 2: Check Network
```
1. Press F12
2. Click Network tab
3. Refresh page
4. Look for failed requests (red)
5. Click failed request
6. Read error response
```

### Step 3: Check Database
```
1. Supabase → Table Editor
2. Check each table has data
3. Check relationships correct
4. Check user_profiles has locker_number
```

### Step 4: Check Logs
```
Vercel:
- Dashboard → Project → Logs
- Real-time logs show errors

Supabase:
- Dashboard → Logs
- Shows auth, API, database logs
```

---

## 🆘 EMERGENCY FIXES

### Nuclear Option 1: Reset Database
```sql
-- ⚠️ WARNING: This deletes ALL data!
-- Only use in development/testing

DROP SCHEMA public CASCADE;
CREATE SCHEMA public;

-- Then re-run both migrations
```

### Nuclear Option 2: Redeploy Everything
```bash
# Local
rm -rf node_modules
npm install
npm run dev

# Production
vercel --prod --force
```

### Nuclear Option 3: Start Fresh
1. Delete Vercel project
2. Delete Supabase project
3. Follow GO_LIVE_NOW.md from step 1
4. Use new credentials

---

## 📞 WHEN TO GET HELP

Get help if:
- Issue not in this guide
- Tried all fixes, still broken
- Data loss concern
- Security concern
- Payment issue

**Resources:**
- Supabase Discord: https://discord.supabase.com
- Vercel Support: https://vercel.com/support
- Stack Overflow: Tag questions with supabase, react, vercel

---

## ✅ PREVENTION

### To avoid issues:

1. **Always test locally first**
   ```bash
   npm run dev
   # Test thoroughly before deploying
   ```

2. **Keep backups**
   ```sql
   -- Export data regularly
   -- Supabase → Database → Backups
   ```

3. **Monitor logs daily**
   - Check Vercel logs
   - Check Supabase logs
   - Check console errors

4. **Update carefully**
   - Test changes locally
   - Deploy to preview first
   - Then promote to production

5. **Document changes**
   - Keep track of what you change
   - Note any custom modifications
   - Save SQL queries you run

---

## 🎯 QUICK DIAGNOSTICS

Run this checklist when something breaks:

1. [ ] Is site loading at all?
2. [ ] Can I access Supabase dashboard?
3. [ ] Can I access Vercel dashboard?
4. [ ] Are there console errors?
5. [ ] Are there network errors?
6. [ ] Did I recently change something?
7. [ ] Did deployment succeed?
8. [ ] Are environment variables set?
9. [ ] Is database accessible?
10. [ ] Is domain resolving?

**If 8+ YES:** Issue is specific, check above sections  
**If 5-7 YES:** Partial outage, check Supabase/Vercel status  
**If <5 YES:** Major issue, check deployment and database

---

## 💡 PRO TIPS

1. **Use incognito mode** to test without cache
2. **Check from different device** to rule out local issues
3. **Read error messages carefully** - they usually tell you what's wrong
4. **Check recently changed** - new bugs often from recent changes
5. **Test in production** after every deployment

---

## 🎓 LEARNING RESOURCES

**Supabase:**
- Docs: https://supabase.com/docs
- YouTube: Search "Supabase tutorial"

**Vercel:**
- Docs: https://vercel.com/docs
- Deployment: https://vercel.com/docs/deployments

**React:**
- Docs: https://react.dev
- Common errors: Search on Stack Overflow

**Tailwind CSS:**
- Docs: https://tailwindcss.com/docs
- Playground: https://play.tailwindcss.com

---

## 🚨 CRITICAL REMINDERS

1. **Never share service_role key** - It has admin access
2. **Always use environment variables** - Don't hardcode secrets
3. **Test before deploying** - Avoid breaking production
4. **Backup before big changes** - You can't undo database changes
5. **Monitor after deployment** - Watch for new errors

---

**Still stuck? Don't panic!**

1. Take a break (seriously, it helps)
2. Re-read error message
3. Search exact error on Google
4. Try fix in incognito mode
5. Test on different browser
6. Ask for help if needed

**You've got this! 💪**

---

*Remember: Every developer faces bugs. The difference is knowing how to debug them. Use this guide and you'll fix 95% of issues yourself!*

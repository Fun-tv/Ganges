# Ganges Lite - Admin Panel Access Guide

## How to Access the Admin Panel

### Step 1: Navigate to the Admin Login Page
You can access the admin panel in two ways:

1. **From the Footer**: Scroll to the bottom of any page and click on the "Admin" link in the footer
2. **Direct Navigation**: The admin login page will appear when you click the Admin link

### Step 2: Login Credentials
Use the following credentials to access the admin panel:

```
Username: admin
Password: ganges2025
```

### Step 3: Admin Panel Features
Once logged in, you'll have access to:

#### Dashboard
- Overview statistics (Total Customers, Pending Requests, Active Shipments, Revenue)
- Recent activity feed
- Quick insights into business operations

#### Personal Shopper Management
- View all personal shopper requests from customers
- Request details include:
  - Customer information (name, email)
  - Product details (URL, name, color, size, quantity, price)
  - Request status (pending, processing, completed, cancelled)
  - Additional notes from customers
- Actions available:
  - Approve requests
  - View detailed information
  - Reject requests

#### Shipment Management
- Track all customer shipment requests
- Monitor shipment details:
  - Customer locker numbers
  - Destination countries
  - Shipping methods
  - Package weights
  - Request dates
- Process and manage shipments

#### Customer Management
- Complete customer database
- Customer profiles showing:
  - Contact information
  - Order history
  - Total spending
  - Account status
- Actions:
  - View detailed customer profiles
  - Contact customers directly

## Admin Panel Structure

All admin-related files are organized in the `/admin` folder:

```
/admin
├── AdminLogin.tsx     # Login authentication component
├── AdminPanel.tsx     # Main admin dashboard
└── README.md          # Admin documentation
```

## Security Notes

⚠️ **Important**: The current implementation uses simple frontend authentication for demonstration purposes. 

For production deployment, ensure you implement:
- Secure backend authentication
- Encrypted password storage
- Session management
- Role-based access control (RBAC)
- HTTPS/SSL encryption
- Multi-factor authentication (MFA)
- Rate limiting for login attempts
- Audit logging for all admin actions

## Support

For technical support or questions about the admin panel:
- **Email**: gangescompany@gmail.com
- **WhatsApp**: +91 82098 93843
- **Instagram**: @ganges_world

---

**Founder**: Jay Agarwal
**Headquarters**: Malviya Nagar, Jaipur, Rajasthan, India
